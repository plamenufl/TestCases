
/*
 * GET home page.
 */

module.exports = function(weathers){
	var weather = require('../weather');

for(var id in weathers){
	weathers[id] = weather(weathers[id]);
}

var functions = {};

functions.weather = function(req, res){
	var id = req.param('id');

	if(typeof weathers[id] === 'undefined'){
		res.status(404).json({status: 'error'});
    }else{
    	res.json(weathers[id].getInformation());
    }
};



functions.changed = function(req,res){
	var id = req.param('id');

	if(typeof weathers[id] === 'undefined'){
		res.status(404).json({status: 'error'});
    }else{
    	weathers[id].triggerEnd();
    	res.json({status: 'done'});
    }
};

functions.list = function(req, res){
	res.render('list', {
		title: 'All Weathers',
		weathers: weathers});
};

return functions;	
};
	
