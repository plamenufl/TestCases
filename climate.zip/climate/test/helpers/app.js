var app = require('../../app'),
	 weathers = require('../data');

module.exports = app(weathers);