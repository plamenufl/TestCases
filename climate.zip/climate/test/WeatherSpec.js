var app = require('./helpers/app');

var should = require('should'),
	supertest = require('supertest');

describe('weathers', function(){

	//test 1
	it('should return valid weather data for id 01',
	 function(done){

	 	supertest(app)
	 	.get('/weather/01')
	 	.expect(200)
	 	.end(function(err, res){
	 		res.status.should.equal(200);
	 		done();
	 	});
		
	});

	//test 2
	it('should return an error for an invalid weather location id', 
		function(done){

		supertest(app)
		.get('/weather/9999999')
		.expect(404)
		.end(function(err, res){
			res.status.should.equal(404);
			done();
		});
		
	});

	//test 3
	it('should mark weather as changed',
		function(done){
			supertest(app)
			.put('/weather/01/changed')
			.expect(200)
			.end(function(err, res){
				res.status.should.equal(200);
				res.body.status.should.equal('done')

				supertest(app)
				.get('/weather/01')
				.expect(200)
				.end(function(err, res){
					res.status.should.equal(200);
					res.body.endofForecast.should.not.equal(undefined);
					done();
				})
			});

		});

});