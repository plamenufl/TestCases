var Weather = function (){
this.data = {
		id: null,
		location: null,
		temperature: null,
		windspeed: null,
		clouds: null,
		startofForecast: null,
		endofForecast: null
	};

	this.fill = function (info){
		for(var prop in this.data){
		if(this.data[prop] !== 'undefined'){
			this.data[prop] = info[prop];
		 }
	  }

	};

		this.triggerStart = function (){
			this.data.startofForecast = Date.now();
		};
		this.triggerEnd = function(){
			this.data.endofForecast = Date.now();
		};
		this.getInformation = function(){
			return this.data;
		};
 };

module.exports = function (info) {
	
	var instance = new Weather();

	instance.fill(info);

	return instance;
};




 /* var id, location, temperature, windspeed, clouds;

exports.setId = function (iD){
	id = iD;
};

exports.setLocation = function (loc){
	location = loc;
};

exports.setTemperature = function (temp){
	temperature = temp;
};

exports.setWindspeed = function (wind){
	windspeed = wind;
};

exports.setClouds = function (cloud){
	clouds = cloud;
};

exports.getInfo = function(){
	return{
		id: id,
		location: location,
		temperature: temperature,
		windspeed: windspeed,
		clouds: clouds
	};
};






	var values = {
		id: null,
		locaiton: null,
		temperature: null,
		windspeed: null,
		clouds: null,
		startofForecast: null,
		endofForecast: null
	};

	for(var prop in values){
		if(values[prop] !== 'undefined'){
			values[prop] = info[prop];
		}
	}

	var functions = {
		triggerStart: function (){
			values.startofForecast = Date.now();
		},
		triggerEnd: function(){
			values.endofForecast = Date.now();
		},
		getInformation: function(){
			return values;
		}
	};

	return functions;

*/