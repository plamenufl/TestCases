
var http = require('http'),
 	weathers = require('./data'),
	app = require('./app')(weathers);

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});