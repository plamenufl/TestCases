

module.exports = {
	"01":{
	    "id": 01,
		"location": "London",
		"temperature": "56F",
		"windspeed": "10",
		"clouds": "stratocumulus"
	},
	"02":{
	    "id": 02,
		"location": "Paris",
		"temperature": "66F",
		"windspeed": "6",
		"clouds": "nimbocumulus"
	},
	"06":{
	    "id": 06,
		"location": "Berlin",
		"temperature": "64F",
		"windspeed": "8",
		"clouds": "stratus"
	},
	"10":{
	    "id": 10,
		"location": "Zurich",
		"temperature": "70F",
		"windspeed": "9",
		"clouds": "altocumulus"
	},
	"12":{
	    "id": 12,
		"location": "Budapest",
		"temperature": "68F",
		"windspeed": "9",
		"clouds": "cumulonimbus"
	}
};


